const length = (a) => document.getElementById("output").value = 3.281 * +a;
const volume = (a) => document.getElementById("output").value = 1000 * +a;
const area = (a) => document.getElementById("output").value = 1076.391 * +a;