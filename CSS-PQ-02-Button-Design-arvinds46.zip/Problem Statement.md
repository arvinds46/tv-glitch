Problem Statement
------------------

Create a button same as given below using CSS properties alone.

![Button](./Picture2.png)

**Points to consider:**

•	Handling multiple borders while recreating boundaries of the button.

•	Providing Text Shadow and Glow as text formatting.

•	Splitting the background in the main part of button ( adding a linear – gradient with no fade formatting ).

•	Adding nested border radius for all the boxes.
