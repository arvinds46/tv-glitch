Write the HTML & CSS Code to achieve the design. Please observe the details in the design. 
Please refer **"radio_output"** for the given design. The concept of radio buttons, padding, and margins will be observed specifically. 

You are free to use any fonts but the colors and positions of the elements must be matching with given design.