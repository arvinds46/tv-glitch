Problem Statement
-

Go through the `index.html`, in order to complete the below given exercises.

1. Prepare the `style.css` to modify the given interface, providing different colours and styles for the various lines in jerry.html

2. For reference to the font style and colour, refer below table:

  **Font families:** Verdana, Arial, Courier, Comic Sans MS

  **Color/Background Color:** green, yellow, white, black
