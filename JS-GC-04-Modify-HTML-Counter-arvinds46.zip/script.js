const add = (count) => document.getElementById("counter").value = +count + 1;
const sub = (count) => document.getElementById("counter").value = +count - 1;