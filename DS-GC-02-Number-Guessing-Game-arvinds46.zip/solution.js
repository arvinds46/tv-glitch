export function NumberGame() {
  let random = [...Array(20).keys()];
  let guess = random[(Math.floor(Math.random() * random.length))]; console.log(guess);
  let number = [];
  for (let i = 1; i <= 10; i++) {
    const num = prompt("Guess a number from 1 to 20\n");
    number.push(num);
    if (guess == num) {
      prompt("You win!! Your score is 5. Your guesses are :" + number.join(","));
      break;
    }
    else {
      prompt("Wrong Guess!! Enter another number :" + num);
      if (i == 10) prompt("You can not guess the number!! Your score is 0");
      continue;
    }
  }
}