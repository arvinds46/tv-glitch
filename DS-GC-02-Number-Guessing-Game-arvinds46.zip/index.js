import {NumberGame} from "./solution.js"

function main() {
  NumberGame()
}

main()