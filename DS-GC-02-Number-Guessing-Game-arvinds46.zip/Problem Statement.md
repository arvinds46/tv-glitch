Problem Statement
---

Lets play a game, where you will select a random number between 1 and 20 and your friend has to guess it.

**The rules are:**
- Each friend will have 10 guess.
- If your friend has guessed the number, print "You win!! Your score is 5. Your guess are: 8 10 9 3 5"
- Score = 10 - total_no_of_guess
- If your freind can not guess the number with 10 guess, print "You can not guess the number!! Your score is 0"

Write a program to implement this game.

**Input:**
- A random number
- All the guesses with a enter followed by

**Output:**
- `Wrong Guess!! Enter another number: ` if entered number is wrong.
- `You can not guess the number!! Your score is 0` if gussing is exhausted.
- `You win!! Your score is 5. Your guesses are: 8 10 9 3 5` if guess are correct.

**Constranits:**
- Each number will be non zero positive number

**Sample Input:**
- First line contains a random number
- Following line contains the guesses
  ```
  Enter a number: 6
  Wrong Guess!! Enter another number: 9
  Wrong Guess!! Enter another number: 3
  Wrong Guess!! Enter another number: 2
  Wrong Guess!! Enter another number: 7
  ```

**Sample Output:**
  ```
  You win!! Your score is 5. Your guesses are: 6, 9, 3, 2, 7
  ```

### **ONLY MODIFY THE `solution.js` FILE.**
### **DO NOT MODIFY ANY OTHER FILES.**