You are responsible for creating a web page for school Time table. Please refer the design given by client in "timetable- output.png".

Hints :- 
HTML - Table Tag
CSS - Background Color, Color, Margine, Padding

_You can select any two colors, fonts by your choice. _