document.getElementById("id1").append("Arvind B S");
document.getElementById("id2").append("Arvind");