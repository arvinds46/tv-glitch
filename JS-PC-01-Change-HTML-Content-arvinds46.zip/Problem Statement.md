## **Problem Statement**

The `index.html` has two header tags. Change the header content to use your name using JS.

### **Write any JS code in the `script.js` file.**