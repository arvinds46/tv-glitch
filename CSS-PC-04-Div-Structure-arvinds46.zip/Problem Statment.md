You are asked by your client to give a structural layout of the webpage you can design for his / her company. Develope a webpage using HTML & CSS to match the mentioned output. Please refer "div-structure-output.png" for output of your project. 
Your webpage must satisfy following consditions :-

1. Logo must be clickable. After clicking on image, it should direct to "https://en.wikipedia.org/wiki/India"
2. Side bar links must be treated as hyperlinks.
3. Use button for "May I help You!" element in the footer section.
4. Try to match different color combinations.
5. Use of external Css is prefered 

You can use following dummy content :- 
"Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe deserunt veritatis iusto provident esse mollitia minima maxime, non a maiores culpa. Corporis consequuntur quo, voluptas in officiis illum aspernatur sunt, esse maxime ab obcaecati molestias commodi quod! Fugiat tempore delectus quos, est quia in. Neque ipsum explicabo adipisci consequuntur numquam." 