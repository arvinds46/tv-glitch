var A = [2, 5, 7, 8, 9];
// sums
let sums = A.reduce(function (accumVariable, curValue) {
return accumVariable + curValue;
}, 0);
document.write(`<h1>Addition of all Numbers is ${sums}</h1>`);

function dec2bin(dec) {
  return (dec >>> 0).toString(2);
}
document.write(`<h1>Binary numbers are ${A.filter(n => dec2bin(n))}</h1>`);

const isOdd = (n) => (n & 1) === 1;
document.write(`<h1>Odd numbers are ${A.filter(n => isOdd(n))}</h1>`);
document.write(`<h1>Even numbers are ${A.filter(n => !isOdd(n))}</h1>`);

function arrayMin(arr) {
  var len = arr.length, min = Infinity;
  while (len--) {
    if (Number(arr[len]) < min) {
      min = Number(arr[len]);
    }
  }
  return min;
};
function arrayMax(arr) {
  var len = arr.length, max = -Infinity;
  while (len--) {
    if (Number(arr[len]) > max) {
      max = Number(arr[len]);
    }
  }
  return max;
};
document.write(`<h1>Maximum Number is ${arrayMax(A)}</h1>`);
document.write(`<h1>Minimum Number is ${arrayMin(A)}</h1>`);