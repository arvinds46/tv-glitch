Consider an array a = [2,5,7,8,9] and write a JS code to perform following operations...
1. Find the addition of all elements of given array. (0.25 marks)
2. Find the Binary conversion of all elements in given array. (0.25 marks)
3. Find out the even and odd numbers from all elements of given array without using Math.max() & Math.min(). (0.25 marks)
4. Find the maximum and minimum numbers from all elements of given array.(0.25 marks)