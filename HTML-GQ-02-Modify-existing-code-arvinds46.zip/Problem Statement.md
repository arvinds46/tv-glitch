Problem Statement
--------------------------
You have been hired for a project where you need to fix an existing "Profile" section for a website. The developer who built the page used a single <p> tag because of which all the contact information is being displayed in a single line. You need to fix it without adding any more <p> tags.