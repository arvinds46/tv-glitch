Client want you to develop a web application using HTML, CSS & Bootstrap. This must include following elements. 
1. Create a button at the Center of the DOM. 
**Button Details** -
Text = "Click me for Menu bar"
Width = Fit to contents, Height = 25px
BG Color = Green (before Click), Red (After click)
Border Radious - 25px

2. If user clicks a Button, Side Menubar should get appear on the DOM which is **hidden initially.**


3. **Sidebar Details -**
4. a. Height = 100px, Width = 25%
5. b. Background Color = Gray
6. Note - You are free to use different links in the sidebar(optional)
