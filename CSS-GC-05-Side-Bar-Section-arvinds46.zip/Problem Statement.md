You are working on the landing page for a project and you have been asked to code the section as shown in the image. Build this using HTML and CSS. **Here Symbols used in sidebar before every titles are most prioritised.**

_Note_ - You can use any image as a Logo of the page. But links must look as they appear in design. Please refer **"SideBar.png"** for output design. 