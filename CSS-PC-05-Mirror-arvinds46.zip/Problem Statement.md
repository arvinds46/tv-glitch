Write the HTML & CSS Code to achieve the design. Please observe the details. Take "**Mirror_input.png"** as input to the HTML code and create its mirror image. 
Please refer **"Mirror_output"** for the given design. 

