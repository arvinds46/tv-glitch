You are working on an analytics dashboard where you are required to show some stats as shown in the design. Implement this using HTML and CSS.
![image](output.png)