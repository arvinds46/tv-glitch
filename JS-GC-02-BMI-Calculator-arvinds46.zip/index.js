var weight = prompt("Enter weight in kgs") * 1;
var height = prompt("Enter height in meters") * 1;

function bmicalc(weight,height) {
  var bmi =  ~~(weight / (height * height));//63 & 1.63
  if (bmi <= 18.4) return `${bmi} Underweight`;
  else if (bmi > 18.5 && bmi < 24.9) return `${bmi} Normal`;
  else if (bmi > 25 && bmi < 29.9) return `${bmi} Overweight`;
  else if (bmi > 30) return `${bmi} Obese`;
}

document.getElementById("bmi").append(bmicalc(weight,height));
