Problem Statement
------------------------------
You are working on a finance management website where you are required to show the recent deposits made by the user. Replicate the following output using only HTML code.

**Note : Check the output.png file in the Files menu for the output.**

![image](output.png)

