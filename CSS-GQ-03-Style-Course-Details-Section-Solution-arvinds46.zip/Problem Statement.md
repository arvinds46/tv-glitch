Problem Statement
------------------------------
You are working on a course details page and this is the design that has been shared with you. Implement the following using HTML and CSS.

**Add your code to the styles.css file**

![image](output.png)


