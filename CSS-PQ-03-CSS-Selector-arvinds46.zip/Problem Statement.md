Modify the index.html with external style.css file to achive the output mentioned in the "output.png". 
Following task to be achieved. 
1. Create a style.css
2. Try to connect it with index.html
3. Use different selctors to target the different elements in html page.
4. Try to achieve the Output mentioned in "outup.png".

   You can use the following contents.
   
   "CSS stands for Cascading Style Sheets. CSS describes how HTML elements are to be displayed on screen, paper, or in other media. CSS saves a lot of work. It can control the layout of multiple web pages all at once. External stylesheets are stored in CSS files."