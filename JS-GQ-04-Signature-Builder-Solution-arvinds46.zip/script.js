function createSignature() {
  var userInput = String(document.querySelector(".user-input").value);
  var firstName = userInput.split(" ")[0];
  var lastName = userInput.split(" ")[1];
  var fullSignature = document.querySelectorAll(".full-signature");
  fullSignature.forEach((element) => {
    var fullSignatureString = firstName[0].toUpperCase() + firstName.slice(1).toLowerCase() + " " + lastName[0].toUpperCase() + lastName.slice(1).toLowerCase();
    element.innerHTML = fullSignatureString;
  })
  var halfSignature = document.querySelectorAll(".half-signature");
  halfSignature.forEach((element) => {
    var halfSignatureString = firstName[0].toUpperCase() + ". " + lastName[0].toUpperCase() + lastName.slice(1).toLowerCase();
    element.innerHTML = halfSignatureString;
  })
}