## **Problem Statement**

Make a signature builder using HTML, CSS and JS.

To provide a stylisis signature take the user's name using a text field input.

Choose some stylisis font (at least 5 & at most 10) from internet to make the signature.

Show a full name signature and a short name signature. Short name has first letter of first name and full last name.

Update the full-name signature field live when the user is writing the name.

Also give a sample in each font after the loading of the page to show some sample text.

### **Write any JS code in `script.js` file.**

### **Write any CSS code in `style.css` file.**