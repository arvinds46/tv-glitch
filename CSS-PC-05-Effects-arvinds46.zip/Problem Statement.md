You are going to create a HTML Web Page having special effects on various elements of HTML using CSS properties. 
Please Execute following instructions.

1. Your webpage must have 2 H1 elements. Each H1 element must change the color after taking point onto it. (Original color - Yellow, Changed color - Black)
   
2. Your webpage must have an image at centre of the page and it must be aoutomatically zoom-in when user take a curser over it.
3. Internal Css is expected. 
   

Note - You are free to use any Heading content and Image. 