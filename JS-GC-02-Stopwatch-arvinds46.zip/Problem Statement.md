## **Problem Statement**

Build a stopwatch using HTML and JavaScript.

There should be a START, STOP and RESET button for the stopwatch.

Also display this text for 2 seconds before the stopwatch will appear in the screen with the button.
```
STOPWATCH IS LOADING...
```

Display two decimel place in the second.

### **Write any JS code in `script.js` file.**