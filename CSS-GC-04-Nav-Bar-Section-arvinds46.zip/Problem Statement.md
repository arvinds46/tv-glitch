You are working on the landing page for a project and you have been asked to code the section as shown in the image. Build this using HTML and CSS.
Note - You can use any image as a Logo of the page. But links must look as they appear in design. Please refer **"Nav.png"** for output design. 
