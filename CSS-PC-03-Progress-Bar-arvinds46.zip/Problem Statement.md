Write the HTML & CSS Code to achieve the design. Please observe the details in the design. 
Please refer **"Progress Bar_output"** for the given design. 

You are free to use any fonts but the colors and positions of the elements must be matching with given design.