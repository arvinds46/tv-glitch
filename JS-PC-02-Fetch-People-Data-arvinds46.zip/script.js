//Async and Await
async function fetchPeople() {
  try {
    const resp = await fetch("https://swapi.dev/api/people/2?format=json");
    const details = await resp.json();
    const homewrld = await fetch(`${details.homeworld}?format=json`);
    const homeworld = await homewrld.json();
    const films = details.films;
    let film=[];
    films.forEach(flm => {
      (async () => {
        const flm1 = await getFilms(flm);
        film.push(flm1.title);
      })();
    });
    const spe = details.species;
    const speces = await fetch(`${spe}?format=json`);
    const species = await speces.json();
    document.getElementById("moviedetails").innerHTML =`<div class="col-12 col-sm-3">
        <div class="card" style="width: 30rem;">
                        <div class="card-body">
                          <h5 class="card-title">Name: ${details.name}</h5>
                          <p class="card-text"><b>Height:</b> ${details.height}<br>
                          <b>Mass:</b> ${details.mass} kgs<br>
                          <b>Hair Color:</b> ${details.hair_color}<br>
                          <b>Skin Color:</b> ${details.skin_color}<br>
                          <b>Eye Color:</b> ${details.eye_color}<br>
                          <b>Birth Year:</b> ${details.birth_year}<br>
                          <b>Gender:</b> ${details.gender}<br>
                          <b>Home World:</b> ${homeworld.name}<br>
                          <b>Films:</b><br>${film.join("<br>")}<br>
                          <b>Species:</b> ${species.name} <b>Classification:</b> ${species.classification}<br>
                          </p>
                        </div>
        </div>
                </div>`;
  } catch(err) {
    console.log("Error: ", err);
  }
}
async function getFilms(flm) {
  try {
    let flm1 = await fetch(`${flm}?format=json`);
    return await flm1.json();
  } catch(err) {
    console.log("Error: ", err);
  }
}
fetchPeople();