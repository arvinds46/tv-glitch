Problam Statement
--------------------

You are given a task to create a web page in which firstly introduction of webpage is given with heading and then courses that it offered are listed through bullet points and after that a registration form is there. You can provide styling by yourself. The Details of all this are given below:

### **Main Heading:**
```
TATA All Courses in One Website
```

### **Must do styling:**

1.	**Background:** Black
2.	Main Heading should be in centre

### **Introduction part:** 
```
Tata is starting a new project in which it will be providing various courses that will help students to learn various things, it doesn’t matter whether they are from tech background or computer background or not. This is a great initiative that TATA Group in order to support students and this will help them a lot. Courses are given below.
```

Now the courses offered have to be in form of bullet points:

```
Programming Language Course
Data Structure and algorithm
Frontend Course
Backend Course
Data science Course
```

### **Form:**
1.	First Name (Mandatory)
2.	Last Name (Mandatory)
3.	Email Id (Mandatory)
4.	Mobile Number (Mandatory)
5.	College Name (Mandatory)
6.	DOB (Mandatory)
7.	Address

### **Button:**

1. Submit Button

### **Validations:**

1. **Email:** It should contain 1 `@` char
2. **Mobile Number:** It should be of 10 digits and no alphabet is allowed.
3. **DOB:** Age must be greater than 16 yrs.
4. **First Name/Last Name:** Name should not have any number.
