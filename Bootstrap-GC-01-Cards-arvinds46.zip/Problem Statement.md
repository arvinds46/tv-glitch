Client want you to develope a web application using Bootstrap Only. You have been assign following task to achieve the given design. 
1. Import all Bootstrap Libraries into your HTML document.
2. Impliment the Card components. Search for the Matching elements in the cards and customize the changes.
   
_Note - Please refer the Cards-output.png for the design. Exact color scheme is expected. _