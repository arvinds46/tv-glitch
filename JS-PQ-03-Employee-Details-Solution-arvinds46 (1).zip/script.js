var employeeNameString = prompt("Enter employee names:");
var employeeNames = employeeNameString.split(" ");

let HTMLString = "";

employeeNames.forEach((item) => {
  var name = item.replace("_", " ");
  var firstName = name.split(" ")[0].toLowerCase();
  var lastName = name.split(" ")[1].toLowerCase();
  name = `${ToCamelCase(firstName)} ${ToCamelCase(lastName)}`;
  var email = `${firstName}.${lastName}@abc.com`;
  var userName = `${firstName}${ToCamelCase(lastName)}`;
  var password = `${lastName}#${ToCamelCase(firstName)}`;
  HTMLString += `${name}\n${email}\n${userName}\n${password}\n\n`
})
document.getElementById("solution").innerText = HTMLString;

/**
* @param string {String} // sherlock
* @returns {string} // Sherlock
*/

function ToCamelCase(string) {
  return `${string[0].toUpperCase()}${string.slice(1).toLowerCase()}`
}