## **Problem Statement**

Suppose you are making emails, usernames, and a password for all the employees of a company. The format of email, username, and password is as follows

email: `<first_name>.<last_name>@abc.com`

username: `<first_name><last_name_with_first_letter_capital>`

password: `<last_name>#<first_name_with_first_letter_capital>`

Take all name input at once where each name will be separated by a space and first and last names will be joined with an underscore.

Output all the names, emails, usernames, and passwords on the screen under the `h2` tag.

Use function to implement any repetitive work.

**Sample Input:**

```
Lionel_Messi Cristiano_Ronaldo Luis_Suarez
```

**Sample Output:**

```
Lionel Messi
lionel.messi@abc.com
lionelMessi
messi#Lionel

Cristiano Ronaldo
cristiano.ronaldo@abc.com
cristianoRonaldo
ronaldo#Cristiano

Luis Suarez
luis.suarez@abc.com
luisSuarez
suarez#Luis
```

Put all HTML element inside the span tag and use no header

```
<span id = "solution"><\span>
```

### **Write any JS code in `script.js` file.**