Problem Statement
------------------------------
You are working on the landing page for a project and you have been asked to code the section as shown in the image. Build this using HTML and CSS.

**Add your code to the styles.css file**

![image](output.png)


