Problem Statement
------------------------------
You are working on a custom footer where the client wants you to add a “Join the community” section. This is the design they have shared with you. Use HTML and CSS to replicate this output.

-----------------------
Test Case 1 : <style>
Test Case 2 : border-radius: 10px;
Test Case 3 : padding: 20px;
Test Case 4 : display: flex;


**Add your code to the styles.css file.**

![image](output.png)


