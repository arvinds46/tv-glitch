var validCountries = ["afghanistan", "armenia", "azerbaijan", "bahrain", "bangladesh", "bhutan", "brunei", "cambodia", "china", "georgia", "india", "indonesia", "iran", "iraq", "israel", "japan", "jordan", "kazakhstan", "kuwait", "kyrgyzstan", "laos", "lebanon", "malaysia", "maldives", "mongolia", "myanmar", "nepal", "north korea", "oman", "pakistan", "palestine", "philippines", "qatar", "russia", "saudi arabia", "singapore", "south korea", "sri lanka", "tyria", "taiwan", "tajikistan", "thailand", "turkey", "turkmenistan", "united arab emirates", "uzbekistan", "vietnam", "yemen"];

var capitals = ["kabul", "yerevan", "baku", "manama", "dhaka", "thimphu", "bandar seri begawan", "phnom penh", "beijing", "tbilisi", "new delhi", "jakarta", "tehran", "baghdad", "jerusalem", "tokyo", "amman", "nur-sultan", "kuwait city", "bishkek", "vientiane", "beirut", "kuala lumpur", "male", "ulaanbaatar", "naypyidaw", "kathmandu", "pyongyang", "muscat", "islamabad", "ramallah", "manila", "doha", "moscow", "riyadh", "singapore", "seoul", "sri jayawardenepura kotte", "damascus", "taipei", "dushanbe", "bangkok", "ankara", "ashgabat", "abu dhabi", "tashkent", "hanoi", "sana'a"];

function find() {
  var country = String(document.querySelector(".input").value).toLowerCase();

  if (validCountries.includes(country)) {
    var index = validCountries.indexOf(country);
    var capital = capitals[index];
    var imageSource = `.\\flag images\\${ToCamelCase(country)}.png`

    document.getElementById("capital").innerText = `Capital: ${ToCamelCase(capital)}`;

    document.getElementById("flag").innerHTML = `<img src='${imageSource}' style="border: 1px black solid">`
  } else {
    alert("INVALID COUNTRY: COUNTRY IS EITHER INVALID OR NOT IN ASIA")
  }
}

/**
* @param string {String}
* @returns {String}
*/

function ToCamelCase(string) {
  let camelCaseStrings = []
  string.split(" ").forEach((item) => {
    camelCaseStrings.push(`${item[0].toUpperCase()}${item.slice(1).toLowerCase()}`);
  })
  return camelCaseStrings.join(" ");
}