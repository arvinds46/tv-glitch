## **Problem Statement**

You will be given an array of numbers. Write the `isArraySorted` function using recursion to tell whether the array is sorted in ascending order or not.

**Input:**

-	Array of number `array`.

**Return:**

-	`1` for sorted array.
-	`0` for unsorted array.

**Constraints:**

-	The size of array: [10, 50].
-	Each number is non-zero positive number.

**Sample Input:**

- One line contains comma separated data for `array`

```
10, 20, 30, 40, 60, 50
```

**Sample Output:**

```
0
```

### **ONLY MODIFY THE `solution.js` FILE.**
### **DO NOT MODIFY ANY OTHER FILES.**