import { isArraySorted } from "./solution.js"

function main() {
  var array = [];
  prompt("").split(", ").forEach((item) => {
    array.push(parseInt(item));
  })
  var result = isArraySorted(array);
  console.log(result);
}

main()