/**
 * @param {number[]} array 
 * @returns {number}
 */

export function isArraySorted(array) {
  // Write your code here
  if (array[0] > array[1]) {
    return 0;
  }
  else if (array.length == 2) {
    return (array[0] < array[1]) ? 1 : 0;
  }
  else if (array.length == 1) {
    return 1;
  }
  else {
    var redusedArray = array.slice(1);
    return isArraySorted(redusedArray);
  }
}