Write the HTML & CSS Code to achieve the design. Please observe the details in the design. 
Please refer **"buttons_output.png"** for the given design. 

Note - You are free to use any fonts but the background color MUST be the same as given in the output image.