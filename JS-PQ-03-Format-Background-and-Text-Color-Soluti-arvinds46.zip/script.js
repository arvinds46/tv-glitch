var button = document.querySelector(".js-submit-button");
button.addEventListener("click", function() {
  var backgroundColor = document.querySelector(".js-background-color").value;
  let textColor;
  switch (backgroundColor.toLowerCase()) {
    case "red": {
      textColor = "white";
      break;
    }
    case "blue": {
      textColor = "white";
      break;
    }
    case "green": {
      textColor = "white";
      break;
    }
    case "yellow": {
      textColor = "black";
      break;
    }
    default: {
      backgroundColor = "white";
      textColor = "black";
      console.error("INVALID COLOR")
      break;
    }
  }
  var body = document.querySelector("body");
  body.style.backgroundColor = backgroundColor;
  body.style.color = textColor;
})