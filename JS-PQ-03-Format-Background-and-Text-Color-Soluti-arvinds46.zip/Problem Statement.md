## **Problem Statement**

Change the background and text colour of HTML page using JavaScript.

You will take the background colour input from user using event and change the colour using event listener.

**Valid Background Colour:**

- Red
- Blue
- Yellow
- Green
- *Default:* White

**Text colour for background colour:**

- White: Red, Blue, Green
- Black: Yellow & Default

Take only background colour input from the user.

### **Write any JS code in `script.js` file.**