## **Problem Statement**

Make a bill using the html code. The format of the bill will be as follows:

- `h2` heading of `BILL`
- `h4` heading of all the items' price
- `h3` heading of the total price.

Take total no. of item from user and all other items as 
` <item_name> <item_price>`.

**Sample Input:**

```
3
Notebook 90
Pen 10
Book 250
```

**Sample Output**

```
BILL
Notebook: 90
Pen: 10
Book: 250
--------------
TOTAL: 350
```

Use only JavaScript to complete this assignment. Do not modify `index.html` file. Insert `BILL` under a `h1` header tag and rest all html code inside
```
<span id = "solution"><\span>
```

### **Write any JS code in `script.js` file.**