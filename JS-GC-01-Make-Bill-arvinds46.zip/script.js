var note = prompt("Enter Notebook_price") * 1;
var pen = prompt("Enter pen_price") * 1;
var book = prompt("Enter book_price") * 1;
document.getElementById("solution").innerHTML = `<h4 id="note">Notebook: </h4><h4 id="pen">Pen: </h4><h4 id="book">Book: </h4><hr><h3 id="total">TOTAL: </h3>`;
document.getElementById("note").append(note);
document.getElementById("pen").append(pen);
document.getElementById("book").append(book);
document.getElementById('total').append(`${note+pen+book}`);