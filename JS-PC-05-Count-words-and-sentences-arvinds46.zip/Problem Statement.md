## **Problem Statement**

Write an HTML script, which will tell the user the number of words and number of sentences the user writes, while the user is writing.

Use Event Listener and Query Selector in your script.

### **Write any JS code in `script.js` file.**