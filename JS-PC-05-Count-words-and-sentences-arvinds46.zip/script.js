var textbox = document.querySelector(".js-text");

textbox.addEventListener("keyup", function(event) {
  var text = String(event.target.value);
  var words = text.split(" ").length;
  var sentences = text.split(". ").length;
  document.getElementById("words").innerText = words;
  document.getElementById("sentences").innerText = sentences;
})