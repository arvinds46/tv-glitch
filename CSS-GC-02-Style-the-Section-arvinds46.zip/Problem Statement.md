Problem Statement
---

You are working on a product page and you are required to implement the following output using HTML and CSS.

![image](output.png)