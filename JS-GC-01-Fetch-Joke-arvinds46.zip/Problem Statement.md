## **Problem Statement**

There is a api which will respond with random joke eachtime it is called. Write a script with HTML and JS to output a joke everytime user clicks a Button which is at the center of the screen. .

The API: https://backend-omega-seven.vercel.app/api/getjoke

The return object will have two parameter: `question` and `punchline`. Output both in seperate line.

### **Write any JS code in `script.js` file.**