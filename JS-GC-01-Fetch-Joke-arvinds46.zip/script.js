//Async and Await
async function fetchData() {
  try {
    const resp = await fetch("https://backend-omega-seven.vercel.app/api/getjoke");
    const joke = await resp.json();
    document.querySelector("h1").innerHTML = joke[0]['question'];
    document.querySelector("h2").innerHTML = joke[0]['punchline'];
  } catch(err) {
    console.log("Error: ", err);
  }
}