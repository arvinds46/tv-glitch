Try to impliment forllowing elements using Bootstrap only. 
1. Grid layout
2. Cards (atleast 3 different types)
3. Close Buttons