Problem Statement
------------------------------
You are working on the “About” Page of a restaurant and this is the content that has been provided to you. Write the HTML code to replicate this output.

**Note : Check the output.png file in the Files menu for the output.**

![image](output.png)

Content
------------------------------
Title - About Us

Heading 1 - Our Chef and Staff

Content under heading 1 - With 20 years of experience cooking in the finest restaurants, our chef is excited to present their vision to you and all our guests, Our caring and committed staff make sure you have a fantastic experience with us.

Heading 2 – Dine in or take out

Content under heading 2 - We have worked to package our meals in a way that lets you bring the quality of our meals into your home. We always love to see you in person, but even when we can't we ensure that your dining experience is top notch!

Heading 3 – Seasonal and local

Content under heading 3 - We refuse to compromise on quality in our restaurant. That's why we source our fresh ingredients from local farmers' markets. No matter what time of year, you can be sure you're eating the best of the season.
