Problem Statement
------------------------------
You have been hired by a freelance content creator to design a website for her. She has uploaded videos on YouTube and she wants to show them on her website. Write the HTML script to achieve this functionality. You can take any random YouTube video for this task.