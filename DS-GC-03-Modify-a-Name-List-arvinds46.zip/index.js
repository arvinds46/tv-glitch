var listOfNames = [];
listOfNames.push(prompt("Enter a Name"));
alert(listOfNames[listOfNames.length-1] + " is added to the list");
var option = 1;
function options() {
  option = prompt("\nYour options:\n1. Add Name\n2. Delete Last Entered Name\n3. Modify a Name\n4. End of Transaction") * 1;
  if (option == 1) {
    prompt(`Enter your option: 1\n`);
    listOfNames.push(prompt("Enter a Name"));
    alert(listOfNames[listOfNames.length-1] + " is added to the list\n");
    options();
  }
  else if (option == 2) {
    prompt(`Enter your option: 2\n`);
    alert(listOfNames.pop() + " is deleted successfully.\n");
    options();
  }
  else if (option == 4) {
    prompt(`Enter your option: 4\n`);
    prompt(`Your entered names are:\n${listOfNames.join("\n")}`);
    options();
  }
  return option;
}
options();
if (option == 1) {
  prompt(`Enter your option: 1\n`);
  listOfNames.push(prompt("Enter a Name"));
  alert(listOfNames[listOfNames.length-1] + " is added to the list\n");
  options();
}
else if (option == 2) {
  prompt(`Enter your option: 2\n`);
  alert(listOfNames.pop() + " is deleted successfully.\n");
  options();
}
else if (option == 4) {
  prompt(`Enter your option: 4\n`);
  prompt(`Your entered names are:\n${listOfNames.join("\n")}`);
  options();
}