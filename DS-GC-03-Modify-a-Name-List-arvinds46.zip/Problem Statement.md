Problem Statement
---

Write a program to accept a list of names from the user and give the user some options to modify the list. Print the list at the end of the transaction.

**Options:**
1. **Add Name:**

   Input:
   ```
   Enter a name: John Smith
   ```
   Output:
   ```
   John Smith is added to the list

2. **Delete Last Entered Name:**

   Output:
   ```
   John Smith is deleted successfully.
   ```

3. **Modify a Name:**

   Input:
   ```
   Enter existing name: John Smith
   Enter modified name: Johan Smith
   ```
   Output:
   ```
   John Smith is modified to Johan Smith
   ```
   If `John Smith` does not exist
   ```
   Can not find name: John Smith
   ```

4. **End of Transaction:**
   Output:
   ```
   Your entered names are:
   Michel Smith
   Steven Smith
   Johan Smith
   ```

**A sample flow:**
```
Enter the list: Michel Smith, Steven Smith

Your options:
1. Add Name
2. Delete Last Entered Name
3. Modify a Name
4. End of Transaction
Enter your option: 1

Enter a name: John Smith
John Smith is added successfully

Your options:
1. Add Name
2. Delete Last Entered Name
3. Modify a Name
4. End of Transaction
Enter your option: 4

Your entered names are:
Michel Smith
Steven Smith
Johan Smith
```

### **ONLY MODIFY THE `index.js` FILE.**
### **DO NOT MODIFY ANY OTHER FILES.**