var totinc = prompt("How much is your Total Income?") * 1;
document.getElementById("totinc").append('₹ ' + totinc);
var tottax = document.getElementById("tottax");
function taxperc(perc, totinc) {
  return ~~(totinc * perc) / 100;
}
if (totinc < 250000) 
  tottax.append("No Tax");
else if (totinc > 250000 && totinc < 500000)
  tottax.append('₹ ' + taxperc(5, totinc));
else if (totinc > 500000 && totinc < 1000000)
  tottax.append('₹ ' + taxperc(10, totinc));
else if (totinc > 1000000)
  tottax.append('₹ ' + taxperc(20, totinc));